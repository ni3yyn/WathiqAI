import fastify from 'fastify';
import cors from '@fastify/cors';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import cron from 'node-cron';

import { processChat, streamChat } from './agent/agent';
import { getProducts } from './wathiq/backendClient';
import { runAutonomousWorker } from './autonomous_worker';
import { parseContributionImages } from './agent/contributionParser';
import { sessionMemory } from './agent/sessionMemory';

dotenv.config();

const server = fastify({ logger: true });

// ─── 1. FASTIFY CORS REGISTRATION (NO TOP-LEVEL AWAIT -> ZERO TS ERRORS) ─────
server.register(cors, {
    origin: true, // Dynamically reflects origin (localhost:3000, localhost:5173, production domains)
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Accept'],
});

// ─── 2. LIGHTWEIGHT HEALTH PING ENDPOINT (FOR UPTIMEROBOT) ───────────────────
server.get('/health', async (request, reply) => {
    return {
        status: 'alive',
        timestamp: Date.now(),
        uptime: process.uptime(),
        sessions: sessionMemory.stats(), // per-session memory diagnostics
    };
});

// ─── 3. ROOT LANDING PAGE ───────────────────────────────────────────────────
server.get('/', async (request, reply) => {
    try {
        let htmlPath = path.join(process.cwd(), 'public', 'index.html');
        if (!fs.existsSync(htmlPath)) {
            htmlPath = path.join(process.cwd(), 'src', 'public', 'index.html');
        }
        const htmlContent = fs.readFileSync(htmlPath, 'utf-8');
        return reply.type('text/html').send(htmlContent);
    } catch (e) {
        return { status: 'ok', name: 'Wathiq Intelligence MVP Agent', endpoint: 'POST /api/chat' };
    }
});

// ─── 4. SMART PARSE ENDPOINT FOR CONTRIBUTIONS DASHBOARD ────────────────────
server.post('/api/parse-contribution', async (request, reply) => {
    try {
        const body = request.body as any;
        if (!body || (!body.frontImage && !body.inciImage)) {
            return reply.status(400).send({ error: 'Missing image URLs' });
        }

        const result = await parseContributionImages({
            frontImage: body.frontImage,
            inciImage: body.inciImage,
            brandHint: body.brand,
            nameHint: body.name
        });

        return reply.status(200).send(result);
    } catch (error: any) {
        console.error('[SERVER] Smart Parse Error:', error);
        return reply.status(500).send({ error: 'Failed to parse images', details: error?.message || error });
    }
});

// ─── 5. CHAT ENDPOINT (SSE STREAMING + JSON FALLBACK) ───────────────────────
server.post('/api/chat', async (request, reply) => {
    try {
        const body = request.body as any;
        if (!body || !body.message) {
            return reply.status(400).send({ type: 'error', message: 'Missing message in request body' });
        }

        console.log(`[AGENT] request received: ${body.message}`);

        const wantsStream = body.stream === true || request.headers.accept?.includes('text/event-stream');

        if (wantsStream) {
            reply.raw.writeHead(200, {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache, no-transform',
                'Connection': 'keep-alive',
                'Access-Control-Allow-Origin': '*'
            });

            // Client closed the tab / connection dropped → stop generating
            // (the old code kept streaming and burning model tokens).
            const abortController = new AbortController();
            reply.raw.on('close', () => {
                if (!reply.raw.writableEnded) abortController.abort();
            });

            const sendSSE = (eventData: any) => {
                if (reply.raw.writableEnded || reply.raw.destroyed) return;
                reply.raw.write(`data: ${JSON.stringify(eventData)}\n\n`);
            };

            try {
                const finalResult = await streamChat(body, {
                    onStatus: (status: string) => {
                        sendSSE({ type: 'status', status });
                    },
                    onTextDelta: (delta: string) => {
                        sendSSE({ type: 'text-delta', delta });
                    },
                    onCardReady: (cardType: string, data: any) => {
                        sendSSE({ type: 'card', cardType, data });
                    }
                }, { abortSignal: abortController.signal });

                sendSSE({ type: 'finish', data: finalResult });
            } catch (err: any) {
                console.error('[AGENT] Stream error:', err);
                sendSSE({ type: 'error', message: err.message || 'Stream processing failed' });
            } finally {
                if (!reply.raw.writableEnded) reply.raw.end();
            }

            return;
        }

        // Non-streaming fallback for curl / standard JSON
        const result = await processChat(body);
        return reply.status(200).send(result);
    } catch (error: any) {
        console.error('[AGENT] Error processing chat', error);
        return reply.status(500).send({
            type: 'error',
            message: 'An internal error occurred',
            details: error?.message || error
        });
    }
});

// ─── 6. AUTONOMOUS NIGHTLY WORKER SCHEDULE (3:00 AM) ────────────────────────
cron.schedule('0 3 * * *', async () => {
    try {
        await runAutonomousWorker();
    } catch (e) {
        console.error('[CRON] Autonomous worker failed:', e);
    }
});

const PORT = parseInt(process.env.PORT || '3001', 10);

// ─── 7. SERVER STARTUP & CATALOG CACHE WARM-UP ───────────────────────────────
const start = async () => {
    try {
        // Warm the catalog cache before opening the port
        try {
            const products = await getProducts();
            server.log.info(`[STARTUP] Catalog warmed: ${products.length} products cached`);
        } catch (warmErr) {
            server.log.warn({ err: warmErr }, '[STARTUP] Catalog warm-up failed, will retry lazily on first request');
        }

        await server.listen({ port: PORT, host: '0.0.0.0' });
        console.log(`Wathiq Intelligence MVP Agent listening on http://localhost:${PORT}`);
    } catch (err) {
        server.log.error(err);
        process.exit(1);
    }
};

start();